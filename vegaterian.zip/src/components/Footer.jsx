function Footer() {
  return (
    <div className="bg-orange-600 text-center">
      <p>Abdulaliyev Jamshidbek</p>
    </div>
  );
}

export default Footer;
